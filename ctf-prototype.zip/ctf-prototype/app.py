from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager,
    UserMixin,
    login_user,
    login_required,
    logout_user,
    current_user
)
import bcrypt

# ----------------------------------------
# BASIC APP SETUP (NO CONFIG FILES)
# ----------------------------------------

APP_NAME = "Govind CTF Challenge"

app = Flask(__name__)
app.config["SECRET_KEY"] = "dev-secret-key"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///ctf.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.init_app(app)

# ----------------------------------------
# DATABASE MODELS
# ----------------------------------------

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    score = db.Column(db.Integer, default=0)

class Challenge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=False)
    points = db.Column(db.Integer, nullable=False)
    flag_hash = db.Column(db.String(200), nullable=False)

class Solve(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    challenge_id = db.Column(db.Integer, nullable=False)

# ----------------------------------------
# LOGIN HANDLER
# ----------------------------------------

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ----------------------------------------
# ROUTES
# ----------------------------------------

@app.route("/")
def home():
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if User.query.filter_by(username=username).first():
            flash("Username already exists")
            return redirect(url_for("register"))

        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        user = User(username=username, password=hashed)

        db.session.add(user)
        db.session.commit()

        flash("Account created. Please login.")
        return redirect(url_for("login"))

    return render_template("register.html", app_name=APP_NAME)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        user = User.query.filter_by(username=username).first()
        if user and bcrypt.checkpw(password.encode(), user.password.encode()):
            login_user(user)
            return redirect(url_for("dashboard"))

        flash("Invalid username or password")
        return redirect(url_for("login"))

    return render_template("login.html", app_name=APP_NAME)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    challenges = Challenge.query.all()
    solved_ids = [
        s.challenge_id
        for s in Solve.query.filter_by(user_id=current_user.id).all()
    ]

    return render_template(
        "dashboard.html",
        challenges=challenges,
        solved_ids=solved_ids,
        app_name=APP_NAME
    )

@app.route("/challenge/<int:cid>", methods=["GET", "POST"])
@login_required
def challenge(cid):
    challenge = Challenge.query.get_or_404(cid)
    solved = Solve.query.filter_by(
        user_id=current_user.id,
        challenge_id=cid
    ).first()

    if request.method == "POST" and not solved:
        flag = request.form["flag"]

        if bcrypt.checkpw(flag.encode(), challenge.flag_hash.encode()):
            db.session.add(Solve(user_id=current_user.id, challenge_id=cid))
            current_user.score += challenge.points
            db.session.commit()
            flash("Correct flag!")
            return redirect(url_for("dashboard"))
        else:
            flash("Wrong flag.")

    return render_template(
        "challenge.html",
        challenge=challenge,
        solved=bool(solved),
        app_name=APP_NAME
    )

# ----------------------------------------
# SEED CHALLENGES
# ----------------------------------------

def seed():
    if Challenge.query.first():
        return

    def h(flag):
        return bcrypt.hashpw(flag.encode(), bcrypt.gensalt()).decode()

    challenges = [
        Challenge(
            title="HTML Secrets",
            description="Find the hidden comment in the page source.",
            points=50,
            flag_hash=h("flag{view_source}")
        ),
        Challenge(
            title="Base64 Baby",
            description="Decode: ZmxhZ3tiYXNlNjRfaXNfZWFzeX0=",
            points=50,
            flag_hash=h("flag{base64_is_easy}")
        ),
        Challenge(
            title="Caesar Shift",
            description="Decode: iodj{fdhvdu}",
            points=75,
            flag_hash=h("flag{caesar}")
        )
    ]

    db.session.add_all(challenges)
    db.session.commit()

# ----------------------------------------
# RUN
# ----------------------------------------

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        seed()

    app.run(debug=True)
