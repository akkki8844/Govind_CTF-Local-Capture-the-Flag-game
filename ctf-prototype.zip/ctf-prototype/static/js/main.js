document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", () => {
      const btn = form.querySelector("button");
      if (btn) {
        btn.disabled = true;
        btn.textContent = "Processing…";
        btn.style.opacity = "0.7";
      }
    });
  });
});
