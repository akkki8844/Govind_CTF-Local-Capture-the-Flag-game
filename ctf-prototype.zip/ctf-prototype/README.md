# Govind CTF Challenge; Author: Govind Mulchandani

Govind CTF Challenge is a beginner-friendly Capture The Flag (CTF) web application
built using Flask. It runs entirely on a local machine and is designed as a clean,
fully functional prototype.

## Features

- User registration and login
- Secure password hashing (bcrypt)
- Beginner CTF challenges
- Flag submission and scoring
- Session-based authentication
- Local SQLite database

## Tech Stack

- Python (Flask)
- Flask-Login
- Flask-SQLAlchemy
- SQLite
- HTML / CSS / JavaScript

## How to Run

1. Install dependencies:
